var hierarchy =
[
    [ "bwx_sdk::bwxLanguage", "dc/d04/classbwx__sdk_1_1bwx_language.html", null ],
    [ "bwx_sdk::bwxProperty< T >", "d3/d8d/classbwx__sdk_1_1bwx_property.html", null ],
    [ "bwx_sdk::bwxPropertyMap< K, V >", "de/dcb/classbwx__sdk_1_1bwx_property_map.html", null ],
    [ "bwx_sdk::bwxPropertyVector< T >", "da/d17/classbwx__sdk_1_1bwx_property_vector.html", null ],
    [ "wxCmdLineParser", null, [
      [ "bwx_sdk::bwxCmdLineParser", "d1/d96/classbwx__sdk_1_1bwx_cmd_line_parser.html", null ]
    ] ],
    [ "wxLocale", null, [
      [ "bwx_sdk::bwxInternat", "db/d8b/classbwx__sdk_1_1bwx_internat.html", null ]
    ] ]
];