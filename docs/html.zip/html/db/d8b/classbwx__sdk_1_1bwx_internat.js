var classbwx__sdk_1_1bwx_internat =
[
    [ "bwxInternat", "db/d8b/classbwx__sdk_1_1bwx_internat.html#aaed65c0981b81e7187d920ba459ee798", null ],
    [ "bwxInternat", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a20cab51ba2d5b0e2ed52482d20e5aea6", null ],
    [ "bwxInternat", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a7f167c435dce70c5ceb17519d6aa89d8", null ],
    [ "AddLanguage", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a1bfe816685962afebbba24e15442edc8", null ],
    [ "AddLanguage", "db/d8b/classbwx__sdk_1_1bwx_internat.html#af1e0864f990ccda12f382ad61e3f6976", null ],
    [ "AddLanguageEnglish", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a33e73677ad418b5a6424bcc042683065", null ],
    [ "AddLanguageGerman", "db/d8b/classbwx__sdk_1_1bwx_internat.html#ad2eadb495a8367dbe523ae306f84d14f", null ],
    [ "AddLanguagePolish", "db/d8b/classbwx__sdk_1_1bwx_internat.html#ac8526f352f41000c976be38b14ed2ef8", null ],
    [ "AddLanguageSystemDefault", "db/d8b/classbwx__sdk_1_1bwx_internat.html#ad52c5214daf2ada723af65b8765dfbed", null ],
    [ "DontUseShortCatalogNames", "db/d8b/classbwx__sdk_1_1bwx_internat.html#ad23b8a42ce5854978f6838ce66ce22b8", null ],
    [ "GetDefaultAppLanguage", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a10cc36dc193fa0f2be5116ad96fe741f", null ],
    [ "GetDefaultAppLanguageCode", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a451f66a04399855254c32c8b61cc3e05", null ],
    [ "GetLangFolderName", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a2d3c26262a27d793734b5588fa074a46", null ],
    [ "GetLangNames", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a6ca1c52e42db7723cd2d9e9b42cd93da", null ],
    [ "Init", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a565d19b16ba51ee3c5d15b82104564de", null ],
    [ "InitByName", "db/d8b/classbwx__sdk_1_1bwx_internat.html#ac3e1e4b02884640f99df29a1273053fe", null ],
    [ "ResetToDefaultLanguage", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a33e36a59d9c3d992f5add8bbd7008962", null ],
    [ "SetDefaultAppLanguage", "db/d8b/classbwx__sdk_1_1bwx_internat.html#af03a385b0444706c6fcbf9ab653667fe", null ],
    [ "SetDefaultAppLanguage", "db/d8b/classbwx__sdk_1_1bwx_internat.html#af659dea2d9f1b3c1fb44731ef8d522f0", null ],
    [ "SetLangFolderName", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a815655f652835722fe3beccb011c8866", null ],
    [ "UseShortCatalogNames", "db/d8b/classbwx__sdk_1_1bwx_internat.html#a961638b090f59fe7e984ab81a778908a", null ]
];