var annotated_dup =
[
    [ "bwx_sdk", "de/df1/namespacebwx__sdk.html", [
      [ "bwxCmdLineParser", "d1/d96/classbwx__sdk_1_1bwx_cmd_line_parser.html", "d1/d96/classbwx__sdk_1_1bwx_cmd_line_parser" ],
      [ "bwxInternat", "db/d8b/classbwx__sdk_1_1bwx_internat.html", "db/d8b/classbwx__sdk_1_1bwx_internat" ],
      [ "bwxLanguage", "dc/d04/classbwx__sdk_1_1bwx_language.html", "dc/d04/classbwx__sdk_1_1bwx_language" ],
      [ "bwxProperty", "d3/d8d/classbwx__sdk_1_1bwx_property.html", "d3/d8d/classbwx__sdk_1_1bwx_property" ],
      [ "bwxPropertyMap", "de/dcb/classbwx__sdk_1_1bwx_property_map.html", "de/dcb/classbwx__sdk_1_1bwx_property_map" ],
      [ "bwxPropertyVector", "da/d17/classbwx__sdk_1_1bwx_property_vector.html", "da/d17/classbwx__sdk_1_1bwx_property_vector" ]
    ] ]
];