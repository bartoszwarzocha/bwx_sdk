var bwx__internat_8h =
[
    [ "bwx_sdk::bwxLanguage", "dc/d04/classbwx__sdk_1_1bwx_language.html", "dc/d04/classbwx__sdk_1_1bwx_language" ],
    [ "bwx_sdk::bwxInternat", "db/d8b/classbwx__sdk_1_1bwx_internat.html", "db/d8b/classbwx__sdk_1_1bwx_internat" ],
    [ "WX_DECLARE_STRING_HASH_MAP", "d9/dd9/bwx__internat_8h.html#ac805570dc61e94d54d4053f95682b2c9", null ],
    [ "bwxDEFAULT_LANG_FOLDER", "d9/dd9/bwx__internat_8h.html#a017a06cfe9cf166a82036a39a1d450d8", null ]
];