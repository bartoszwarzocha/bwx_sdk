var namespaces_dup =
[
    [ "bwx_sdk", "de/df1/namespacebwx__sdk.html", "de/df1/namespacebwx__sdk" ]
];