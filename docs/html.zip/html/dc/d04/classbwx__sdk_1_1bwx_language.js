var classbwx__sdk_1_1bwx_language =
[
    [ "bwxLanguage", "dc/d04/classbwx__sdk_1_1bwx_language.html#a30668caedb438b0ef6afe8b35af9ff06", null ],
    [ "bwxLanguage", "dc/d04/classbwx__sdk_1_1bwx_language.html#a500dc1b12cc202b4b061723dd6f74af5", null ],
    [ "GetName", "dc/d04/classbwx__sdk_1_1bwx_language.html#a2208277eb11b4de10bce6ad8888a036a", null ],
    [ "GetShortName", "dc/d04/classbwx__sdk_1_1bwx_language.html#a49aa154bcf8fc3d4439d8589dee2afe1", null ],
    [ "GetUnicodeName", "dc/d04/classbwx__sdk_1_1bwx_language.html#ac90b2950c6bc7c78235d60925d1fa79e", null ],
    [ "GetWxLangCode", "dc/d04/classbwx__sdk_1_1bwx_language.html#acb183fc7653e5c558a4c4e2054a8b953", null ],
    [ "SetName", "dc/d04/classbwx__sdk_1_1bwx_language.html#ae4a475ab12a6685b328cf65cbb29ea7d", null ],
    [ "SetShortName", "dc/d04/classbwx__sdk_1_1bwx_language.html#a46bdbc225532d2b7414cf971418f456c", null ],
    [ "SetUnicodeName", "dc/d04/classbwx__sdk_1_1bwx_language.html#ae1cbc5c3ee2baeaf7bc1ccbb776aa0fb", null ],
    [ "SetWxLangCode", "dc/d04/classbwx__sdk_1_1bwx_language.html#a5bab0b3569b6b5e8e63c4e17ad2f1897", null ]
];