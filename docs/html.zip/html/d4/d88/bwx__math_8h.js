var bwx__math_8h =
[
    [ "bwxCPI", "d4/d88/bwx__math_8h.html#a3d36c0a05dea961f9d38b9a79922d228", null ],
    [ "bwxDPI", "d4/d88/bwx__math_8h.html#add36aab171a3345a08edbc6229e1cf71", null ],
    [ "bwxEpsilon", "d4/d88/bwx__math_8h.html#a1ebf47c2a7fb3528296dd8bec3b56cfa", null ],
    [ "bwxHPI", "d4/d88/bwx__math_8h.html#a4be6d9c51ecc9c2e3468a4020cd69630", null ],
    [ "bwxPI", "d4/d88/bwx__math_8h.html#a42eda03511f4b6a25a4b66797c69b05a", null ],
    [ "bwxQPI", "d4/d88/bwx__math_8h.html#a0d1826bd7b0e91ca46ea924d9997b89b", null ],
    [ "bwxSPI", "d4/d88/bwx__math_8h.html#a6709fc78b55717376768ff7193846317", null ],
    [ "bwxSQRT2", "d4/d88/bwx__math_8h.html#af49d8b6902689a0f1a97d7bf97730a2a", null ],
    [ "bwxIntermediate", "d4/d88/bwx__math_8h.html#a41e0b606cc4e23001352b6e01dd0b56e", null ],
    [ "bwxIsPower2", "d4/d88/bwx__math_8h.html#a1191cca2de2498471c70beb559793792", null ],
    [ "bwxNextMultiple", "d4/d88/bwx__math_8h.html#a5f8f1a0212e2e780f38c084656e7948f", null ],
    [ "bwxNextMultiple", "d4/d88/bwx__math_8h.html#af11defede64919963ea0962162e4b69a", null ],
    [ "bwxNextPower2", "d4/d88/bwx__math_8h.html#a7009c479967b19e281f339e43f7aaa97", null ],
    [ "bwxRand", "d4/d88/bwx__math_8h.html#a897a0c4491b580cf785d6c8e7ffb15c9", null ],
    [ "bwxRand", "d4/d88/bwx__math_8h.html#aebb28685cf9ad81687dfb3939c8ba8a4", null ],
    [ "bwxToDegrees", "d4/d88/bwx__math_8h.html#a454031efa249abb9d9b5a1e61e1d3d4d", null ],
    [ "bwxToRadians", "d4/d88/bwx__math_8h.html#a049579bdd7aeba61ad5e22308a5c4408", null ]
];