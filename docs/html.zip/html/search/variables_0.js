var searchData=
[
  ['bwxdefault_5flang_5ffolder_0',['bwxDEFAULT_LANG_FOLDER',['../de/df1/namespacebwx__sdk.html#a017a06cfe9cf166a82036a39a1d450d8',1,'bwx_sdk']]]
];
