var searchData=
[
  ['wx_5fdeclare_5fstring_5fhash_5fmap_0',['WX_DECLARE_STRING_HASH_MAP',['../de/df1/namespacebwx__sdk.html#ac805570dc61e94d54d4053f95682b2c9',1,'bwx_sdk']]],
  ['wxdeclare_5fevent_1',['wxDECLARE_EVENT',['../d4/d5e/bwx__oop_8h.html#acd8f2a7760b36dcb0744c6f8b1ddbec1',1,'wxDECLARE_EVENT(EVT_PROPERTY_CHANGED, wxCommandEvent):&#160;bwx_oop.h'],['../d4/d5e/bwx__oop_8h.html#af688ad98637c47494a199776f5bc61b3',1,'wxDECLARE_EVENT(EVT_PROPERTY_VECTOR_CHANGED, wxCommandEvent):&#160;bwx_oop.h'],['../d4/d5e/bwx__oop_8h.html#a0795dfeacd46f82d3d4f2fb92349fd40',1,'wxDECLARE_EVENT(EVT_PROPERTY_MAP_CHANGED, wxCommandEvent):&#160;bwx_oop.h']]]
];
